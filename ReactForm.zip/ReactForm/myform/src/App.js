import Signin from "./Components/Signin/Signin";
import {BrowserRouter} from 'react-router-dom';

const App = () =>{
  return(
    <BrowserRouter>
      <Signin/>
    </BrowserRouter>
  )
}

export default App;