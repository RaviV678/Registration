import { SignupContent } from "../UserContent";
import Style from '../Signin/SigninStyle.module.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Link } from 'react-router-dom';
import { SubButton } from "../Signin/SigninComp";
import { FacebookLoginButton, InstagramLoginButton, LinkedInLoginButton } from "react-social-login-buttons";
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { Form } from "react-bootstrap";
import { useForm } from "react-hook-form";
import { Fragment, useState } from "react";
import axios from 'axios';

const SignupComp = () => {
    const schema = yup.object({
        email: yup.string().required('Email must be required!!!').email('Enter a valid email'),

        password: yup.string().required('Password must be required!!!')
            .min(6, 'Password must be six characters long'),

        retypePass: yup.string().required('Retype password must be required!!!')
            .min(6, 'Password must be six characters long')
            .oneOf([yup.ref('password')], "Password does't match"),

        mobile: yup.string().required('Mobile no. must be required!!!')
            .matches(/^[0-9]{10}$/ , 'Enter a valid mobile number'),
    })


    const { register, handleSubmit, formState: { errors } } = useForm({
        resolver : yupResolver(schema)
    })
    const [msg , setMsg] = useState(null)

    const onSubmit = data => {
        axios.post('http://localhost:9001/signup' , data) 
        .then(res => setMsg(res.data.message))       
    }

    return (
        <> 
            {
                msg ? msg==='Successfully Registered!!!' ? <div className="alert alert-success">{msg}</div>
                : <div className="alert alert-danger">{msg}</div>
                : null
            }
            <Form onSubmit={handleSubmit(onSubmit)}>
                {
                    SignupContent.map((item, key) =>
                        <Fragment  key={key}>
                            <div className={`${Style.inputGrp} d-flex mb-4`}>
                                <div className={`${Style.icon}`}>
                                    <FontAwesomeIcon icon={item.icon} style={{ fontSize: '20px', color: '#454545' }} />
                                </div>
                                <input type={item.type} placeholder={item.placeholder} className={`${Style.input}`} {...register(item.name, { required: true })} />
                            </div>
                            {errors[item.name] ? <p className={`${Style.error} mb-4 text-danger`}>{errors[item.name].message}</p> : null}
                        </Fragment>
                    )
                }

                <SubButton data={{ title: 'SIGN UP' }} />

                <p className='text-center my-4' style={{ fontWeight: 'bold', color: '#454545' }}>OR</p>

                <FacebookLoginButton>
                    <span>Sign up with Facebook</span>
                </FacebookLoginButton>
            </Form>
        </>
    )
}

export default SignupComp;