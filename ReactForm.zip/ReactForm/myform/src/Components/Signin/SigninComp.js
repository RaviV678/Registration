import Style from './SigninStyle.module.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Link } from 'react-router-dom';
import { SigninContent } from '../UserContent';
import { useForm } from 'react-hook-form';
import { Form } from 'react-bootstrap';
import { Fragment, useState } from 'react';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import axios from 'axios';

const schema = yup.object({
    email: yup.string().required('Email must be required!!!').email('Enter a valid email'),
    password: yup.string().required('Password can not be empty!!!').min(6, 'Password must be six characters long')
}).required();

const SigninComp = () => {
    const [msg, setMsg] = useState(null)

    const onSubmit = data => {
        axios.post('http://localhost:9001/login', data)
            .then(res => setMsg(res.data.message))
    }

    const { register, handleSubmit, formState: { errors } } = useForm({
        resolver: yupResolver(schema)
    })

    return (
        <>
            {
                msg ? msg === 'Successfully Login' ? <div className="alert alert-success">{msg}</div>
                    : <div className="alert alert-danger">{msg}</div>
                    : null
            }
            <Form onSubmit={handleSubmit(onSubmit)}>
                {
                    SigninContent.map((item, key) =>
                        <Fragment key={key}>
                            <div className={`${Style.inputGrp} d-flex mb-4`}>
                                <div className={`${Style.icon}`}>
                                    <FontAwesomeIcon icon={item.icon} style={{ fontSize: '20px', color: '#454545' }} />
                                </div>
                                <input type={item.type} placeholder={item.placeholder} className={`${Style.input}`} {...register(item.name)} />
                            </div>
                            {errors[item.name] ? <p className={`${Style.error} mb-4 text-danger`}>{errors[item.name].message}</p> : null}
                        </Fragment>
                    )
                }

                <SubButton data={{ title: 'LOGIN' }} />

                <p className='text-center my-4' style={{ fontWeight: 'bold', color: '#454545' }}>OR</p>

                <div className='mb-3'>
                    <Link to='/forgotPass' className='text-decoration-none' style={{ fontWeight: 'bold', color: '#454545' }}>FORGOT PASSWORD ?</Link>
                </div>
            </Form>
        </>
    )
}

export const SubButton = (props) => {
    return (
        <div className={`${Style.inputGrp} ${Style.BtnBack} d-flex`}>
            <button type='submit' className={`${Style.LoginBtn}`} >{props.data.title}</button>
        </div>
    )
}

export default SigninComp;