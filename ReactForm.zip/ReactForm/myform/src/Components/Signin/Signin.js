import { Form } from 'react-bootstrap';
import Style from './SigninStyle.module.css';
import SigninComp from './SigninComp';
import { useState } from 'react';
import SignupComp from '../Signup/SignupComp';

const Signin = () => {
    // const btnClr = '#de451f'
    const [win , setWin] = useState(false);
    const [logninBtn , setLoginBtn] = useState({'backClr' : '#de451f' , 'color' : '#fff'});
    const [SignupBtn , setSignupBtn] = useState({'backClr' : '#dedede' , 'color' : '#454545'});

    const LoginFun = () =>{
        setWin(false)
        setLoginBtn({'backClr' : '#de451f' , 'color' : '#fff'})
        setSignupBtn({'backClr' : '#dedede' , 'color' : '#454545'})
    }

    const SignupFun = () =>{
        setWin(true)
        setLoginBtn({'backClr' : '#dedede' , 'color' : '#454545'})
        setSignupBtn({'backClr' : '#de451f' , 'color' : '#fff'})
    }

    return (
        <div className={`${Style.form} p-4`}>
            <div className={`${Style.btnGrp} mb-5`}>
                <button className={`${Style.Btn}`} onClick={LoginFun} style={{borderRight : '1px solid #000', background : logninBtn.backClr , color : logninBtn.color}}>LOGIN</button>
                <button className={`${Style.Btn}`} onClick={SignupFun} style={{background : SignupBtn.backClr , color : SignupBtn.color}}>SIGNUP</button>
            </div>

            {
                !win ? <SigninComp /> : <SignupComp />
            }
        </div>
    )
}

export default Signin;