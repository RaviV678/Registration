import { faEnvelope, faLock , faUnlockKeyhole , faPhone } from '@fortawesome/free-solid-svg-icons';

export const SigninContent = [
    {
        placeholder : 'Enter Your ID',
        icon : faEnvelope,
        type : 'text',
        name : 'email'
    },
    {
        placeholder : 'Enter Your Password',
        icon : faLock,
        type : 'password',
        name : 'password'
    }
]

export const SignupContent = [
    {
        placeholder : 'Enter Your Mail',
        icon : faEnvelope,
        type : 'text',
        name : 'email'
    },
    {
        placeholder : 'Enter Your Password',
        icon : faLock,
        type : 'password',
        name : 'password'
    },
    {
        placeholder : 'Retype Your Password',
        icon : faUnlockKeyhole,
        type : 'password',
        name : 'retypePass'
    },
    {
        placeholder : 'Enter Your Mobile No.',
        icon : faPhone,
        type : 'text',
        name : 'mobile'
    }
]