import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';

const app = express()
app.use(express.json())
app.use(express.urlencoded())
app.use(cors())

mongoose.connect('mongodb://localhost:27017/FormDataDB' , {
    useNewUrlParser : true,
    useUnifiedTopology : true
} , ()=>{
    console.log('Database Connected !!')
})

const dbSchema = new mongoose.Schema({
    email : String,
    password : String,
    mobile : String
})

const User = new mongoose.model('User' , dbSchema)

app.get('/' , (req , res)=>{
    res.send('Successfully Working API Route...')
})

app.post('/signup' , (req , res)=>{
    const {email , password , mobile} = req.body
    User.findOne({email : email} , (err , usr)=>{
        if(usr){
            res.send({message : "User Already Registered!!!"})
        }
        else{
            const user = new User({email , password , mobile})
            user.save(err =>{
                if(err){
                    res.send("Something went wrong!!!")
                }
                else{
                    res.send({message : "Successfully Registered!!!"})
                }
            })
        }
    })

})

app.post('/login' , (req , res)=>{
    const {email , password } = req.body
    User.findOne({email : email} , (err , usr)=>{
        if(usr && password === usr.password){
            res.send({message : "Successfully Login"})
        }
        else{
            res.send({message : "Username or Password Incorrect"})
        }
    })

})

app.listen(9001 , ()=>{
    console.log("Server started at http://localhost:9001/")
})